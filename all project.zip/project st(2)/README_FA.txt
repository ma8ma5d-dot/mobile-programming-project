تمرین‌های عملی Kotlin و Android
=================================

محتویات:
- Exercise1_StudentInfo.kt
- Exercise2_CheckGrade.kt
- Exercise3_ForLoop.kt
- Exercise4_Greet.kt
- Exercise5_Book.kt
- Exercise6_NullableString.kt
- AndroidSample/MainActivity.kt
- AndroidSample/activity_main.xml
- Answers_FA.txt

نکته برای اجرای تمرین‌های 1 تا 6:
این فایل‌ها را می‌توانید در یک پروژه Kotlin/JVM در Android Studio یا IntelliJ IDEA اجرا کنید. هر فایل را جداگانه اجرا کنید، چون هر کدام تابع main دارد.

نکته برای تمرین 7:
فایل‌های AndroidSample نمونه‌ای برای پروژه اندروید مبتنی بر Views هستند. یک پروژه جدید در Android Studio بسازید و کدها را در مسیرهای متناظر قرار دهید. نام package در MainActivity.kt را با package پروژه خود یکسان کنید. این ZIP به‌تنهایی APK نصب‌شدنی نیست.
