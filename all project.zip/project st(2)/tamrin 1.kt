fun main() {
    val name: String = "Mohammad"
    val age: Int = 18
    val major: String = "Computer Engineering"

    println("Name: $name")
    println("Age: $age")
    println("Major: $major")
}
