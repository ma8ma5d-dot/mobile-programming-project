fun greet(name: String) {
    println("سلام $name، خوش آمدی!")
}

fun main() {
    greet("Mohammad")
}
