fun main() {
    val grade = 15.5

    if (grade >= 10) {
        println("دانشجو قبول است.")
    } else {
        println("دانشجو مردود است.")
    }
}
