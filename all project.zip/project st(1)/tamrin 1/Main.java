public class Main {
    public static void main(String[] args) {
        String name = "Mohammad";
        int age = 18;

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}
