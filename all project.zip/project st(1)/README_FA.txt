تمرین‌های عملی Java و Android
================================

ساختار پوشه:
1) Exercise1_NameAge/Main.java
2) Exercise2_CheckAge/Main.java
3) Exercise3_AndroidUI/MainActivity.java
4) Exercise3_AndroidUI/activity_main.xml
5) Exercise3_AndroidUI/AndroidManifest.xml
6) Answers_FA.txt

نکته:
- تمرین‌های 1 و 2 برنامه‌های Java ساده هستند و می‌توان آن‌ها را در IntelliJ IDEA یا هر محیط اجرای Java اجرا کرد.
- تمرین 3 فایل‌های نمونه Android هستند. در Android Studio یک پروژه جدید با قالب Empty Views Activity بسازید و فایل‌ها را در مسیرهای متناظر قرار دهید.
- ممکن است لازم باشد نام package در MainActivity.java و AndroidManifest.xml را با package پروژه خودتان یکسان کنید.
