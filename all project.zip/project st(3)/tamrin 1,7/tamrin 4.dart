num multiply(num a, num b) {
  return a * b;
}

void main() {
  print(multiply(4, 5)); // خروجی: 20
}
