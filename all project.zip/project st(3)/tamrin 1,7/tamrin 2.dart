void main() {
  double grade = 15.5;

  if (grade >= 10) {
    print('دانشجو قبول است.');
  } else {
    print('دانشجو مردود است.');
  }
}
