void main() {
  List<String> students = [
    'Ali',
    'Sara',
    'Reza',
    'Mina',
    'Nima',
  ];

  for (String student in students) {
    print(student);
  }
}
