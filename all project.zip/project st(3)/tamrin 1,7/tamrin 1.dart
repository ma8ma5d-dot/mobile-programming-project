void main() {
  String name = 'Mohammad';
  int age = 18;
  String major = 'Computer Engineering';

  print('Name: $name');
  print('Age: $age');
  print('Major: $major');
}
