تمرین‌های عملی جلسه سوم — Dart و Flutter
==========================================

محتویات:
- تمرین‌های مستقل Dart از 1 تا 7 در پوشه dart_exercises
- نمونه پروژه Flutter برای تمرین 8 در پوشه flutter_center_text
- نمونه پروژه Flutter برای تمرین 9 در پوشه flutter_counter
- پاسخ‌های تشریحی فارسی در Answers_FA.txt

اجرای تمرین‌های Dart:
هر فایل را جداگانه با دستور dart run نام_فایل.dart اجرا کنید؛ Dart SDK باید نصب باشد.

اجرای پروژه‌های Flutter:
1. Flutter SDK و Android Studio را نصب کنید.
2. در ترمینال دستور flutter create flutter_center_text و flutter create flutter_counter را اجرا کنید.
3. فایل lib/main.dart هر پروژه را با نسخه داخل پوشه متناظر جایگزین کنید.
4. از پوشه پروژه دستور flutter pub get و سپس flutter run را اجرا کنید.

این ZIP کدها و فایل‌های نمونه را دارد؛ APK از پیش ساخته‌شده داخل آن نیست.
